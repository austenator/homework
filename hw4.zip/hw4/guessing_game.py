# guessing_game
# Austen Henry
import random


# Starts a game in which you guess a number between a tolerance and the game tells
# you if you need to go higher or lower.
def guessing_game(low, high):
    number = random.randint(low, high)
    game_over = False
    while not game_over:
        guess = int(raw_input("Guess a number between " + str(low) + " and " + str(high) + ": "))
        if guess == number:
            print("You win!")
            game_over = True
        elif guess < number:
            print("The magic number is higher.")
        elif guess > number:
            print("The magic number is lower.")
        else:
            print("Error.")
