# main.py
# Austen Henry

from hw4 import more_functions
from hw4 import guessing_game
from hw4 import speech_parser


# Let's first look over the more_functions:
print(more_functions.odd_even_merge([1, 2, 3, 4, 5, 6], [31, 32, 33, 34, 35, 36]))

print(more_functions.make_dict(["hello", "no way", "yes"]))

print(more_functions.transpose_matrix([[1, 2, 3], [4, 5, 6], [7, 8, 9]]))

print(more_functions.squares(10, 5))

# Now that was fun, let's take a break and play a guessing game.
# guessing_game.guessing_game(1, 20)

# Good work! Now to parse some text. This will spit out a file called out.txt.
speech_parser.parse_text("ihaveadream.txt")

