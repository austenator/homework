# speech_parser.py
# Austen Henry


# This takes a text file and parses it to produce the top ten words in it.
def parse_text(filename, write_to_file=False, output_filename="out.txt", ignore_file="ignore.txt", top=10):

    with open(ignore_file, "r") as ignored_file:
        ignored_words = list(ignored_file)

    with open(filename, "r") as speech_file:
        speech = list(speech_file)

    speech1 = process_speech(speech)
    speech2 = remove_ignored(speech1, ignored_words)
    speech3 = sort(speech2)

    # We have the sorted list, now to output the top ten entries.
    with open(output_filename, "w") as output_file:
        output_file.write("The top ten words in " + filename + " are: \n")
        map(lambda x: output_file.write(str(speech3.index(x)+1) + ". " + str(x[0]) + " : " + str(x[1]) + "\n"), speech3)


# Takes the lines of the speech and makes a list of all the words.
def process_speech(speech):
    final = []
    for line in speech:
        final += line.split(" ")

    final_words = map(lambda line: line.lower().strip(), final)
    return final_words


# Processes the ignore.txt and removes all those words from the speech.
def remove_ignored(words, ignored):
    ignored_words = map(lambda line: line.lower().strip(), ignored)
    filtered = [x for x in words if x not in ignored_words]
    return filtered


# Sorts the words into a dictionary: key being the word and value being number of times found.
def sort(speech):
    dic = {}
    for word in speech:
        if word in dic:
            dic[word] += 1
        else:
            dic[word] = 1
    sorted_words = sorted(dic.items(), key=lambda x: x[1], reverse=True)
    return list(sorted_words)[:10]


# Gets the sorted dictionary in reverse by key (number of times found).
def get_top(dic):
    return sorted(dic.items(), key=lambda x: x[1], reverse=True)

#parse_text("ihaveadream.txt")