# more_functions
# Austen Henry

# Merges the odd values of list1 with the even values of list2 and returns the list.
def odd_even_merge(list1, list2):
    merged = filter(lambda x: x % 2 != 0, list1) + filter(lambda x: x % 2 == 0, list2)
    return merged if len(merged) > 0 else []


# Converts a list to a dictionary.
def make_dict(ls):
    dic = {}
    for i in range(len(ls)):
        dic['key'+str(i)] = ls[i]
    return dic


# Transposes a matrix.
def transpose_matrix(matrix):
    return zip(*matrix)


# Merges two dictionaries.
def merge_dicts(dict1, dict2):
    return dict1.update(dict2)


# Gives you a list of 'count' squares starting at start.
def squares(start, count):
    return [x**2 for x in range(start, start+count)]